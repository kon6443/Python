
def introduction():
    print(" _   _        _  _         __        __              _      _  _ ")
    print("| | | |  ___ | || |  ___   \ \      / /  ___   _ __ | |  __| || |")
    print("| |_| | / _ \| || | / _ \   \ \ /\ / /  / _ \ | '__|| | / _` || |")
    print("|  _  ||  __/| || || (_) |   \ V  V /  | (_) || |   | || (_| ||_|")
    print("|_| |_| \___||_||_| \___/     \_/\_/    \___/ |_|   |_| \__,_|(_)")
    print("__        __  _____   _        ____    ___    __  __   _____   _ ")
    print("\ \      / / | ____| | |      / ___|  / _ \  |  \/  | | ____| | |")
    print(" \ \ /\ / /  |  _|   | |     | |     | | | | | |\/| | |  _|   | |")
    print("  \ V  V /   | |___  | |___  | |___  | |_| | | |  | | | |___  |_|")
    print("   \_/\_/    |_____| |_____|  \____|  \___/  |_|  |_| |_____| (_)")

    print("This is a CS552 Computer Science Capstone project in ESU.")
    print("Made by Camaron Edgecomb, Draven George, Hao Lan, Israel Guerra Loza, Junyeong Jang, Onam Kwon, and Zihui Chen.")


def init():
    introduction()

init()